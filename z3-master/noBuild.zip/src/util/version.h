// automatically generated file.
#define Z3_MAJOR_VERSION   4
#define Z3_MINOR_VERSION   7
#define Z3_BUILD_NUMBER    0
#define Z3_REVISION_NUMBER 0

#define Z3_FULL_VERSION    "Z3 4.7.0.0"
